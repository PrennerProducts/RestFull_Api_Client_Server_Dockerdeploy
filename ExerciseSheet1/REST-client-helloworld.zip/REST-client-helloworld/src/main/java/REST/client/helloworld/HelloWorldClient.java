package REST.client.helloworld;

import javax.ws.rs.core.UriBuilder;

import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;


public class HelloWorldClient {

	final static String SERVER_ADDRESS = "localhost";
	final static int SERVER_PORT = 8989;
	final static String SERVER_PATH_PREFIX = "/api";

	public static void main(String args[]) {
		final String urlbase = "http://" + SERVER_ADDRESS + ":" + SERVER_PORT + SERVER_PATH_PREFIX; 
		
		// Create client
		ResteasyClient client = new ResteasyClientBuilder().build();
		ResteasyWebTarget target = client.target(UriBuilder.fromPath(urlbase));
		HelloWorldServiceInterface proxy = target.proxy(HelloWorldServiceInterface.class);
		
		// Get hello message from server
		String msg = proxy.getHelloMessage();
		System.out.println("Received from server: " + msg);
	}
	
}
